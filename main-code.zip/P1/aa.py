import re
from flask import Flask,render_template

aa = Flask(__name__)

@aa.route('/')
def index():
    return render_template('index.html')

@aa.route('/<name>')
def print_name(name):
    return render_template('{}.html'.format(name))

from nsepy import get_history
from datetime import date
data = get_history(symbol="SBIN", start=date(2015,1,1), end=date(2015,1,31))
data[['Close']].plot()

if __name__=='__main__':
    aa.run(debug=1,port=8000)
